package components;
import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** JTree that reports selections by placing their string values
 *  in a JTextField.
 *  1999 Marty Hall, http://www.apl.jhu.edu/~hall/java/
 */

public class SelectableTree extends JFrame
                            implements TreeSelectionListener {
  public static void main(String[] args) {
    new SelectableTree();
  }

  private JTree tree;
  private JTextField currentSelectionField;
  
  public SelectableTree() {	  
   super("JTree Selections");
    WindowUtilities.setNativeLookAndFeel();
    addWindowListener(new ExitListener());
    Container content = getContentPane();
    DefaultMutableTreeNode root =
    new DefaultMutableTreeNode("WFAN - Source tables-->Talend Job-->Target Table");
    DefaultMutableTreeNode child;
    DefaultMutableTreeNode grandChild;
    DefaultMutableTreeNode grandChild1;

	  try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:sqlserver://klt-in-agarg;user=sa;password=sa;database=ag_util");
		Statement sta = null;
		sta = conn.createStatement();
		String Sql = "select tablename from job_src_target where upper(componentname) ";
		Sql += " in ('TJDBCINPUT','TELTJDBCINPUT') and tablename is not null";
		Sql += " group by tablename order by 1";
		ResultSet rs = null;
			rs = sta.executeQuery(Sql);
			while (rs.next()) {
				try {
					child = new DefaultMutableTreeNode(rs.getString("tablename"));
				    root.add(child);	    
				    Statement sta1 = null;	
					sta1 = conn.createStatement();
					String Sql1 = "select jobName From job_src_target";
					Sql1 += " where jobName in ( select jobName from job_src_target";
					Sql1 += " where upper(tablename)='"+rs.getString("tablename").toUpperCase()+"'";
					Sql1 += " and upper(componentname) IN ('TJDBCINPUT','TELTJDBCINPUT')";
					Sql1 += " ) and upper(componentname) IN ('TJDBCOUTPUT','TELTJDBCOUTPUT')";
					Sql1 += " and jobName is not null";
					Sql1 += "  group by jobName";
					ResultSet rs1 = null;
					rs1 = sta1.executeQuery(Sql1);
					while (rs1.next()) {
				        grandChild = new DefaultMutableTreeNode("Talend Job --> "+rs1.getString("jobName").toUpperCase());
				        child.add(grandChild);
					    Statement sta2 = null;	
						sta2 = conn.createStatement();
						String Sql2 = "select tablename From job_src_target";
						Sql2 += " where upper(jobName) = '"+rs1.getString("jobName").toUpperCase()+"'";
						Sql2 += " and upper(componentname) IN ('TJDBCOUTPUT','TELTJDBCOUTPUT')";
						Sql2 += " and tablename is not null";
						Sql2 += "  group by tableName";
						ResultSet rs2 = null;
						rs2 = sta2.executeQuery(Sql2);
						while (rs2.next()) {
					        grandChild1 = new DefaultMutableTreeNode(rs2.getString("tableName").toUpperCase());
					        grandChild.add(grandChild1);
						}				    
				        
					}				    
				    
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	      
	/*	
    for(int childIndex=1; childIndex<4; childIndex++) {
      child = new DefaultMutableTreeNode("Child " + childIndex);
      root.add(child);
      for(int grandChildIndex=1; grandChildIndex<4; grandChildIndex++) {
        grandChild =
          new DefaultMutableTreeNode("Grandchild " + childIndex +
                                     "." + grandChildIndex);
        child.add(grandChild);
      }
    }
    */
    tree = new JTree(root);
    tree.addTreeSelectionListener(this);
    content.add(new JScrollPane(tree), BorderLayout.CENTER);
    currentSelectionField = new JTextField("Current Selection: NONE");
    content.add(currentSelectionField, BorderLayout.SOUTH);
    setSize(250, 275);
    setVisible(true);
  }

  public void valueChanged(TreeSelectionEvent event) {
    currentSelectionField.setText
      ("Current Selection: " +
       tree.getLastSelectedPathComponent().toString());
  }
}
    
